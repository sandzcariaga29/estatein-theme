<?php
/**
 * Plugin Name: Estatein Properties Carousel
 * Description: Registers the Properties CPT and provides a [featured_properties] shortcode.
 * Version: 1.1
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// 1. REGISTER PROPERTIES CPT
function estatein_register_properties_cpt() {
    register_post_type( 'properties', array(
        'labels'      => array( 'name' => 'Properties', 'singular_name' => 'Property', 'add_new_item' => 'Add New Property' ),
        'public'      => true,
        'has_archive' => true,
        'menu_icon'   => 'dashicons-admin-home',
        'supports'    => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
    ));
}
add_action( 'init', 'estatein_register_properties_cpt' );

// 2. ENQUEUE ASSETS
function estatein_carousel_assets() {
    wp_enqueue_style( 'swiper-css', 'https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css' );
    wp_enqueue_script( 'swiper-js', 'https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js', array(), null, false );
    $plugin_css_version = filemtime( plugin_dir_path( __FILE__ ) . 'estatein-carousel.css' );
    wp_enqueue_style( 'estatein-carousel-style', plugins_url( 'estatein-carousel.css', __FILE__ ), array(), $plugin_css_version );
}
add_action( 'wp_enqueue_scripts', 'estatein_carousel_assets' );

// 3. SHORTCODE & HTML
function estatein_properties_shortcode() {
    $args = array( 'post_type' => 'properties', 'posts_per_page' => -1 );
    $query = new WP_Query( $args );
    ob_start(); 
    ?>

    <div class="estatein-carousel-wrapper">
        <div class="carousel-header">
            <div>
                <h2>Featured Properties</h2>
                <p>Explore our handpicked selection of featured properties.</p>
            </div>
            <a href="/properties" class="btn-secondary">View All Properties</a>
        </div>

        <div class="swiper property-swiper">
            <div class="swiper-wrapper">
                <?php if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); 
                    $price = get_field('property_price');
                    $beds  = get_field('property_bedrooms');
                    $baths = get_field('property_bathrooms');
                    $type  = get_field('property_type');
                ?>
                    <div class="swiper-slide property-card">
                        <a href="<?php the_permalink(); ?>">
                            <?php if ( has_post_thumbnail() ) { the_post_thumbnail('large', array('class' => 'property-img')); } ?>
                        </a>
                        <div class="property-info">
                            <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                            <p><?php echo wp_trim_words( get_the_excerpt(), 12, '...' ); ?></p>
                            <div class="property-amenities">
                                <span>🛏️ <?php echo esc_html( $beds ); ?>-Bedroom</span>
                                <span>🛁 <?php echo esc_html( $baths ); ?>-Bathroom</span>
                                <span>📐 <?php echo esc_html( $type ); ?></span>
                            </div>
                            <div class="property-footer">
                                <div>
                                    <span class="price-label">Price</span>
                                    <h4>$<?php echo esc_html( number_format((float)$price) ); ?></h4>
                                </div>
                                <a href="<?php the_permalink(); ?>" class="btn-primary">View Property Details</a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; wp_reset_postdata(); endif; ?>
            </div>
        </div>

        <div class="carousel-bottom-bar">
            <div class="prop-pagination swiper-custom-pagination"></div> 
            <div class="carousel-arrows">
                <div class="prop-btn-prev swiper-btn-prev">←</div>
                <div class="prop-btn-next swiper-btn-next">→</div>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        function initPropSwiper() {
            if (typeof Swiper !== 'undefined') {
                new Swiper('.property-swiper', {
                    slidesPerView: 3,
                    spaceBetween: 20,
                    loop: true,
                    
                    // --- Autoplay Added ---
                    autoplay: {
                        delay: 4000, // Slightly longer delay (4s) for looking at properties
                        disableOnInteraction: false,
                        pauseOnMouseEnter: true,
                    },
                    // ----------------------

                    navigation: { nextEl: '.prop-btn-next', prevEl: '.prop-btn-prev' }, 
                    pagination: { 
                        el: '.prop-pagination', type: 'custom',
                        renderCustom: function (swiper, current, total) {
                            return (current < 10 ? '0' + current : current) + ' <span style="color:#999;">of</span> ' + (total < 10 ? '0' + total : total);
                        }
                    },
                    breakpoints: { 
                        320: { slidesPerView: 1, spaceBetween: 20 }, 
                        768: { slidesPerView: 2, spaceBetween: 20 }, 
                        1024: { slidesPerView: 3, spaceBetween: 20 }
                    }
                });
            } else { setTimeout(initPropSwiper, 100); }
        }
        initPropSwiper();
    });
</script>

    <?php
    return ob_get_clean(); 
}
add_shortcode( 'featured_properties', 'estatein_properties_shortcode' );