<?php
/**
 * Plugin Name: Estatein Properties Carousel
 * Description: Registers the Properties CPT and provides a [featured_properties] shortcode with a Swiper.js carousel.
 * Version: 1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// 1. Register the Custom Post Type (If you already have this in estatein-core, you can remove this block)
function estatein_register_properties_cpt() {
    register_post_type( 'properties', array(
        'labels'      => array( 'name' => 'Properties', 'singular_name' => 'Property', 'add_new_item' => 'Add New Property' ),
        'public'      => true,
        'has_archive' => true,
        'menu_icon'   => 'dashicons-admin-home',
        'supports'    => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
    ));
}
add_action( 'init', 'estatein_register_properties_cpt' );

// 2. Enqueue Swiper JS, CSS, and our Custom Plugin CSS
function estatein_carousel_assets() {
    // Load Swiper from CDN
    wp_register_style( 'swiper-css', 'https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css' );
    wp_register_script( 'swiper-js', 'https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js', array(), null, true );
    
    // Load our custom carousel CSS from the plugin folder
    wp_register_style( 'estatein-carousel-style', plugins_url( 'estatein-carousel.css', __FILE__ ) );
}
add_action( 'wp_enqueue_scripts', 'estatein_carousel_assets' );

// 3. Create the Shortcode
function estatein_properties_shortcode() {
    wp_enqueue_style( 'swiper-css' );
    wp_enqueue_script( 'swiper-js' );
    wp_enqueue_style( 'estatein-carousel-style' );
    
    // Query the properties
    $args = array( 'post_type' => 'properties', 'posts_per_page' => -1 ); // -1 gets all properties for the carousel
    $query = new WP_Query( $args );

    ob_start(); // Start capturing HTML output
    ?>

    <div class="estatein-carousel-wrapper">
        <div class="carousel-header">
            <div>
                <h2>Featured Properties</h2>
                <p>Explore our handpicked selection of featured properties. Each listing offers a glimpse into exceptional homes and investments available through Estatein.</p>
            </div>
            <a href="#" class="btn-secondary">View All Properties</a>
        </div>

        <div class="swiper property-swiper">
            <div class="swiper-wrapper">
                <?php if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); 
                    // ACF Fields
                    $price = get_field('property_price');
                    $beds  = get_field('property_bedrooms');
                    $baths = get_field('property_bathrooms');
                    $type  = get_field('property_type');
                ?>
                    <div class="swiper-slide property-card">
                        <a href="<?php the_permalink(); ?>">
                            <?php if ( has_post_thumbnail() ) { the_post_thumbnail('large', array('class' => 'property-img')); } ?>
                        </a>
                        <div class="property-info">
                            <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                            <p><?php echo wp_trim_words( get_the_excerpt(), 12, '... <a href="'.get_permalink().'" style="color:#fff; text-decoration:underline;">Read More</a>' ); ?></p>
                            
                            <div class="property-amenities">
                                <span>🛏️ <?php echo esc_html( $beds ); ?>-Bedroom</span>
                                <span>🛁 <?php echo esc_html( $baths ); ?>-Bathroom</span>
                                <span>📐 <?php echo esc_html( $type ); ?></span>
                            </div>
                            
                            <div class="property-footer">
                                <div>
                                    <span class="price-label">Price</span>
                                    <h4>$<?php echo esc_html( number_format((float)$price) ); ?></h4>
                                </div>
                                <a href="<?php the_permalink(); ?>" class="btn-primary">View Property Details</a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; wp_reset_postdata(); endif; ?>
            </div>
        </div>

        <div class="carousel-bottom-bar">
            <div class="swiper-custom-pagination"></div> <div class="carousel-arrows">
                <div class="swiper-btn-prev">←</div>
                <div class="swiper-btn-next">→</div>
            </div>
        </div>
    </div>

   <script>
    window.addEventListener('load', function() {
        // Quick safety check to ensure Swiper loaded successfully
        if (typeof Swiper === 'undefined') {
            console.error('Swiper JS failed to load.');
            return;
        }

        const testiSwiper = new Swiper('.testimonial-swiper', {
            slidesPerView: 3, // Forces 3 columns on desktop
            spaceBetween: 30,
            navigation: {
                nextEl: '.testi-btn-next',
                prevEl: '.testi-btn-prev',
            },
            pagination: {
                el: '.testi-pagination',
                type: 'custom',
                renderCustom: function (swiper, current, total) {
                    let curr = current < 10 ? '0' + current : current;
                    let tot = total < 10 ? '0' + total : total;
                    return curr + ' <span style="color:#999;">of</span> ' + tot;
                }
            },
            breakpoints: {
                // Responsive rules so it still looks great on mobile
                320: { slidesPerView: 1, spaceBetween: 20 },
                768: { slidesPerView: 2, spaceBetween: 20 },
                1024: { slidesPerView: 3, spaceBetween: 30 }
            }
        });
    });
    </script>

    <?php
    return ob_get_clean(); // Return the captured HTML
}
add_shortcode( 'featured_properties', 'estatein_properties_shortcode' );