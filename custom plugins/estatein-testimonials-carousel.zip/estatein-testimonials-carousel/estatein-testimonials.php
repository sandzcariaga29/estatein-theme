<?php
/**
 * Plugin Name: Estatein Testimonials Carousel
 * Description: Registers the Testimonials CPT and provides a [featured_testimonials] shortcode.
 * Version: 1.1
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// 1. RESTORE THE CUSTOM POST TYPE
function estatein_register_testimonials_cpt() {
    register_post_type( 'testimonials', array(
        'labels'      => array( 'name' => 'Testimonials', 'singular_name' => 'Testimonial', 'add_new_item' => 'Add New Testimonial' ),
        'public'      => true,
        'has_archive' => false, 
        'menu_icon'   => 'dashicons-format-quote',
        'supports'    => array( 'title', 'editor', 'thumbnail' ),
    ));
}
add_action( 'init', 'estatein_register_testimonials_cpt' );

// 2. ENQUEUE ASSETS
function estatein_testimonials_assets() {
    wp_enqueue_style( 'swiper-css', 'https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css' );
    wp_enqueue_script( 'swiper-js', 'https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js', array(), null, false );
    $plugin_css_version = filemtime( plugin_dir_path( __FILE__ ) . 'estatein-testimonials.css' );
    wp_enqueue_style( 'estatein-testi-style', plugins_url( 'estatein-testimonials.css', __FILE__ ), array(), $plugin_css_version );
}
add_action( 'wp_enqueue_scripts', 'estatein_testimonials_assets' );

// 3. SHORTCODE & HTML
function estatein_testimonials_shortcode() {
    $args = array( 'post_type' => 'testimonials', 'posts_per_page' => -1 );
    $query = new WP_Query( $args );
    ob_start(); 
    ?>

    <div class="estatein-carousel-wrapper">
        <div class="carousel-header">
            <div>
                <h2>What Our Clients Say</h2>
                <p>Read the success stories and heartfelt testimonials from our valued clients.</p>
            </div>
            <a href="#" class="btn-secondary">View All Testimonials</a>
        </div>

        <div class="swiper testimonial-swiper">
            <div class="swiper-wrapper">
                <?php if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); 
                    $rating = get_field('testimonial_rating'); 
                    $name = get_field('client_name');
                    $location = get_field('client_location');
                    $stars_html = '';
                    $rating_count = $rating ? (int)$rating : 5; 
                    for ($i = 0; $i < $rating_count; $i++) { $stars_html .= '⭐'; }
                ?>
                    <div class="swiper-slide testimonial-card">
                        <div class="stars"><?php echo $stars_html; ?></div>
                        <h4><?php the_title(); ?></h4>
                        <p><?php echo wp_trim_words( get_the_content(), 25, '...' ); ?></p>
                        <div class="client-info">
                            <?php if ( has_post_thumbnail() ) { the_post_thumbnail('thumbnail'); } else { echo '<img src="' . get_template_directory_uri() . '/assets/images/default-avatar.png" alt="Client">'; } ?>
                            <div>
                                <h5><?php echo esc_html( $name ? $name : 'Valued Client' ); ?></h5>
                                <span><?php echo esc_html( $location ? $location : 'Location' ); ?></span>
                            </div>
                        </div>
                    </div>
                <?php endwhile; wp_reset_postdata(); endif; ?>
            </div>
        </div>

        <div class="carousel-bottom-bar">
            <div class="testi-pagination swiper-custom-pagination"></div> 
            <div class="carousel-arrows">
                <div class="testi-btn-prev swiper-btn-prev">←</div>
                <div class="testi-btn-next swiper-btn-next">→</div>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        function initTestiSwiper() {
            if (typeof Swiper !== 'undefined') {
                new Swiper('.testimonial-swiper', {
                    slidesPerView: 3,
                    spaceBetween: 20,
                    loop: true,
                    
                    // --- Added Autoplay Section ---
                    autoplay: {
                        delay: 3000, // Time in milliseconds (3 seconds)
                        disableOnInteraction: false, // Keeps autoplay running after user interaction
                        pauseOnMouseEnter: true, // Optional: Pauses when mouse hovers over slider
                    },
                    // ------------------------------

                    navigation: { nextEl: '.testi-btn-next', prevEl: '.testi-btn-prev' },
                    pagination: { 
                        el: '.testi-pagination', type: 'custom',
                        renderCustom: function (swiper, current, total) {
                            return (current < 10 ? '0' + current : current) + ' <span style="color:#999;">of</span> ' + (total < 10 ? '0' + total : total);
                        }
                    },
                    breakpoints: { 
                        320: { slidesPerView: 1, spaceBetween: 20 }, 
                        768: { slidesPerView: 2, spaceBetween: 20 }, 
                        1024: { slidesPerView: 3, spaceBetween: 20 }
                    }
                });
            } else { setTimeout(initTestiSwiper, 100); }
        }
        initTestiSwiper();
    });
</script>

    <?php
    return ob_get_clean(); 
}
add_shortcode( 'featured_testimonials', 'estatein_testimonials_shortcode' );