<?php
/**
 * Plugin Name: Estatein Core Functionality
 * Description: Registers Custom Post Types (Properties, Testimonials, FAQs) for the Estatein theme.
 * Version: 1.0
 * Author: Your Name
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function estatein_register_custom_post_types() {

    // 1. Properties CPT
    $property_labels = array(
        'name'               => 'Properties',
        'singular_name'      => 'Property',
        'menu_name'          => 'Properties',
        'add_new'            => 'Add New Property',
        'add_new_item'       => 'Add New Property',
        'edit_item'          => 'Edit Property',
        'all_items'          => 'All Properties',
    );
    $property_args = array(
        'labels'        => $property_labels,
        'public'        => true,
        'has_archive'   => true,
        'menu_icon'     => 'dashicons-admin-home',
        'supports'      => array( 'title', 'editor', 'thumbnail', 'revisions' ),
        'show_in_rest'  => true, // Enables Gutenberg editor
    );
    register_post_type( 'properties', $property_args );

    // 2. Testimonials CPT
    $testimonial_labels = array(
        'name'               => 'Testimonials',
        'singular_name'      => 'Testimonial',
        'menu_name'          => 'Testimonials',
        'add_new'            => 'Add New Testimonial',
        'add_new_item'       => 'Add New Testimonial',
        'edit_item'          => 'Edit Testimonial',
        'all_items'          => 'All Testimonials',
    );
    $testimonial_args = array(
        'labels'        => $testimonial_labels,
        'public'        => false, // Kept false as they usually don't need their own single pages
        'show_ui'       => true,
        'menu_icon'     => 'dashicons-format-quote',
        'supports'      => array( 'title', 'editor', 'thumbnail' ),
        'show_in_rest'  => true,
    );
    register_post_type( 'testimonials', $testimonial_args );

    // 3. FAQs CPT
    $faq_labels = array(
        'name'               => 'FAQs',
        'singular_name'      => 'FAQ',
        'menu_name'          => 'FAQs',
        'add_new'            => 'Add New FAQ',
        'add_new_item'       => 'Add New FAQ',
        'edit_item'          => 'Edit FAQ',
        'all_items'          => 'All FAQs',
    );
    $faq_args = array(
        'labels'        => $faq_labels,
        'public'        => false,
        'show_ui'       => true,
        'menu_icon'     => 'dashicons-editor-help',
        'supports'      => array( 'title', 'editor' ), // Title is the Question, Editor is the Answer
        'show_in_rest'  => true,
    );
    register_post_type( 'faqs', $faq_args );

}
add_action( 'init', 'estatein_register_custom_post_types' );